// OOP6-A
// Selectable interface
public interface Selectable {
	public abstract void selectByClick(int x, int y);
	}
