// OOP6-A
// MyMouseListener
// MyMouseListener.java
import java.awt.event.*;

public class MyMouseListener extends MouseAdapter {
    private MyPanel panel;
    
    MyMouseListener(MyPanel panel) {
        super();
        this.panel = panel;
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        System.out.println("Clicked at (" + x + ", " + y + ")");
        panel.panelClicked(x, y);  
    }
}
