// OOP6/7-A/B
// Drawable interface
import java.awt.Graphics;

public interface Drawable {
	public abstract void draw(Graphics g);
	}
