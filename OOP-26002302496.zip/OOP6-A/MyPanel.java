// OOP6-A
// MyPanel
// MyPanel.java
import java.awt.*;
import javax.swing.*;
import java.util.List;
import java.util.ArrayList;
import java.awt.event.ActionListener;

public class MyPanel extends JPanel {
    private List<Shape> shapeList;
    private double totalArea; // 計算した面積の合計を保持

    public MyPanel() {
        super();
        this.shapeList = new ArrayList<>();
        this.totalArea = 0.0;

        JButton movebt = new JButton("Move");
        this.add(movebt);
        ActionListener movebtAI = new MoveButtonListener(this);
        movebt.addActionListener(movebtAI);

        JButton calcbt = new JButton("Calc");
        this.add(calcbt);
        ActionListener calcbtAI = new CalcButtonListener(this);
        calcbt.addActionListener(calcbtAI);

        MyMouseListener myMouseListener = new MyMouseListener(this);
        this.addMouseListener(myMouseListener);
    }

    public void addShape(Shape s) {
        this.shapeList.add(s);
        this.repaint();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        System.out.println("MyPanel painting ...");
        for (Shape shape : this.shapeList) {
            if (shape != null) shape.draw(g);
        }

        // 面積の合計を描画する
        g.setColor(Color.BLACK);
        g.drawString("[" + String.format("%.2f", this.totalArea)+"]", 5, 10);
    }

    public void panelClicked(int x, int y) {
        for (Shape shape : shapeList) {
            if (shape != null) {
                shape.selectByClick(x, y);
            }
        }
        this.repaint();
    }

    public void moveShapes(int dx, int dy) {
        for (Shape shape : shapeList) {
            if (shape != null && shape instanceof Selectable) {
                shape.moveSelected(dx, dy);
            }
        }
        this.repaint();
    }

    public void calcSelectedShapeArea() {
        double sumArea = 0.0;
        for (Shape shape : shapeList) {
            if (shape != null && shape instanceof Selectable && shape.moveSelected(0, 0)) {
                sumArea += shape.getArea();
            }
        }
        this.totalArea = Math.floor(sumArea * 100) / 100;
        this.repaint();
    }
}
